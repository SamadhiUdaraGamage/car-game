package com.example.mobilecoursework01;

public class GVariables {

    public static String[] car_names = new String[]{
            "Alto",
            "Aqua",
            "Audi",
            "Axio",
            "Baleno",
            "benz",
            "bezza",
            "BMW_3_Serie",
            "BMW_M4",
            "BMW_X3",
            "Camry",
            "Celerio_X",
            "Corolla",
            "Grand WagonR",
            "Honda Brv",
            "Honda City",
            "Honta Civic",
            "Honda Hr-V",
            "Honda Fit",
            "Jazza",
            "Maruti",
            "Nissan GTR",
            "Nissan Terra",
            "Premio",
            "Prius",
            "Sunny",
            "Vezel",
            "Vitz",
            "Viva Elite",
            "Yaris"

    };

}
